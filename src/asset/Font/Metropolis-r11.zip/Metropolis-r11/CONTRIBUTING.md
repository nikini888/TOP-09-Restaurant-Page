# Contributing

1. Read the [Documentation](./Documentation/Documentation.md)
2. Create a pull request
